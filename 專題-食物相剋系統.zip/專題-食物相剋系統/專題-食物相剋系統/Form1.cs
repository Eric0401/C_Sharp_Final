using System.Text;
using System.Text.Json;

namespace 專題2._0
{

    public partial class Form1 : Form
    {
        //彩虹跑馬燈
        int colorIndex = 0;
        Color[] rainbowColors = new Color[]
        {
            Color.Red, Color.Orange, Color.Khaki, Color.Green,
            Color.Blue, Color.Indigo, Color.Violet
        };

        string filePath = Path.Combine(Application.StartupPath, "accounts.json");// 登入資訊
        AccountStore store = new AccountStore();

        public static Dictionary<string, FoodData> foodInfo = new(); // 食物資訊
        string foodJsonPath = Path.Combine(Application.StartupPath, "food.json");

        public static Dictionary<string, List<Record>> records = new();// 紀錄資訊
        string recordPath = Path.Combine(Application.StartupPath, "records.json");

        public class FoodData
        {
            public List<string> 優點 { get; set; }
            public List<string> 相剋 { get; set; }
            public string 後果 { get; set; }
            public string 解決辦法 { get; set; }
        }
        public class Record
        {
            public string 日期 { get; set; }
            public string 星期 { get; set; }
            public string 餐別 { get; set; }
            public string 食物 { get; set; }
            public string 備註 { get; set; }
            public string 時間 { get; set; }
            public override string ToString()//決定 Record 物件在 ListBox 中要顯示什麼文字
            {
                string notePart = string.IsNullOrEmpty(備註) ? "" : $"（{備註}）";
                return $"{餐別} {時間} {食物} {notePart}";
            }
        }
        public Form1()
        {
            InitializeComponent();
        }
        public class AccountStore
        {
            public List<string> Accounts { get; set; } = new List<string>();
        }
        private void groupBox1_Paint(object sender, PaintEventArgs e)// 消除虛線
        {
            GroupBox box = (GroupBox)sender;
            e.Graphics.Clear(box.BackColor); // 清除預設底色

            using (Pen borderPen = new Pen(Color.Black, 1))
            {
                e.Graphics.DrawRectangle(borderPen, 0, 0, box.Width - 1, box.Height - 1);
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {

            labelMarquee.Text = "歡迎使用食物相剋系統！";
            labelMarquee.Left = this.Width; // 從右邊開始進入
            labelMarquee.Font = new Font("微軟正黑體", 20, FontStyle.Bold);
            labelMarquee.ForeColor = Color.Red; // 初始顏色
            // 建立accounts.json檔案（如不存在）
            if (!File.Exists(filePath))
            {
                string initJson = JsonSerializer.Serialize(store, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(filePath, initJson);
            }
            // 載入帳號清單
            try
            {
                string json = File.ReadAllText(filePath, Encoding.UTF8);
                store = JsonSerializer.Deserialize<AccountStore>(json);
                comboBox1.Items.AddRange(store.Accounts.ToArray());
            }
            catch (Exception ex)
            {
                MessageBox.Show("讀取帳號資料失敗，原因：" + ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // 如果發生錯誤，重新建立一個空的帳號清單
                store = new AccountStore();
            }
            //讀取food.json檔案
            if (File.Exists(foodJsonPath))
            {
                try
                {
                    string foodJson = File.ReadAllText(foodJsonPath, Encoding.UTF8);
                    foodInfo = JsonSerializer.Deserialize<Dictionary<string, FoodData>>(foodJson);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("讀取 food.json 失敗：" + ex.Message);
                }
            }
            //讀取records.json檔案
            if (File.Exists(recordPath))
            {
                try
                {
                    string json = File.ReadAllText(recordPath, Encoding.UTF8);
                    records = JsonSerializer.Deserialize<Dictionary<string, List<Record>>>(json);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("讀取 records.json 失敗：" + ex.Message);
                }
            }
            // 設定計時器
            timerScroll.Start();
            timerColor.Start();
        }

        private void timerScroll_Tick(object sender, EventArgs e)
        {
            // 每次移動2個像素
            labelMarquee.Left -= 12;

            if (labelMarquee.Right < 0)
            {
                labelMarquee.Left = this.Width;
            }
        }

        private void timerColor_Tick(object sender, EventArgs e)
        {
            // 每次改變顏色
            labelMarquee.ForeColor = rainbowColors[colorIndex];
            colorIndex = (colorIndex + 1) % rainbowColors.Length;
        }

        private void button1_Click(object sender, EventArgs e) //儲存帳號按鈕
        {
            string account = textBox1.Text.Trim();

            if (!string.IsNullOrEmpty(account) && !store.Accounts.Contains(account))//string.IsNullOrEmpty(account)檢查帳號是不是空的、!store.Accounts.Contains(account)檢查清單中是否已經有這個帳號
            {
                store.Accounts.Add(account);

                string jsonToSave = JsonSerializer.Serialize(store, new JsonSerializerOptions
                {
                    WriteIndented = true, // 美化 JSON 格式
                    Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping // 保證不會將中文轉換成 Unicode 編碼
                });

                // 使用 UTF-8 編碼儲存 JSON 檔案
                File.WriteAllText(filePath, jsonToSave, Encoding.UTF8);

                comboBox1.Items.Add(account);
            }
            textBox1.Text = "";
        }
        private void button2_Click(object sender, EventArgs e) //確認帳號按鈕
        {
            // 取得選取的帳號名稱
            string selected = comboBox1.SelectedItem?.ToString();
            // 檢查是否選取了帳號
            if (string.IsNullOrEmpty(selected))
            {
                MessageBox.Show("請先選擇一個帳號", "提醒", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            // 開啟 AccountForm，傳入帳號名稱
            AccountForm form = new AccountForm(selected);
            form.Show();
            this.Hide();
        }
        private void button3_Click(object sender, EventArgs e) //刪除帳號按鈕
        {
            // 取得選取的帳號名稱
            string selectedAccount = comboBox1.SelectedItem?.ToString();
            // 檢查是否選取了帳號
            if (string.IsNullOrEmpty(selectedAccount))
            {
                MessageBox.Show("請先從下拉選單中選擇要刪除的帳號", "提醒", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            // 確認刪除
            if (store.Accounts.Contains(selectedAccount))
            {
                // 清除顯示與選取狀態
                comboBox1.SelectedIndex = -1;
                comboBox1.Text = "";

                // 從記憶體中移除
                store.Accounts.Remove(selectedAccount);

                // 更新 JSON 檔案
                string json = JsonSerializer.Serialize(store, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(filePath, json);

                //同時刪除該帳號對應的紀錄資料
                if (records.ContainsKey(selectedAccount))
                {
                    records.Remove(selectedAccount); // 從記憶體移除紀錄

                    //更新 records.json 檔案
                    string recordPath = Path.Combine(Application.StartupPath, "records.json");
                    string recordJson = JsonSerializer.Serialize(records, new JsonSerializerOptions
                    {
                        WriteIndented = true,
                        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
                    });
                    File.WriteAllText(recordPath, recordJson, Encoding.UTF8);
                }

                // 從下拉選單移除
                comboBox1.Items.Remove(selectedAccount);

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            GuestForm guestForm = new GuestForm();
            guestForm.Show();
            this.Hide(); // 隱藏主畫面
        }
    }
}
